import * as React from "react";
type Item = { title: string; qty: number; price: number }; // price in dollars

export default function OrderReceipt(props: {
  orderId: string;
  items: Item[];
  subtotal: number;
  shipping: number;
  tax: number;
  total: number;
}) {
  const { orderId, items, subtotal, shipping, tax, total } = props;
  return (
    <div style={{ fontFamily: "Arial, sans-serif", color: "#111", lineHeight: 1.4 }}>
      <h2>Thank you for your order! ✅</h2>
      <p>Order ID: <strong>{orderId}</strong></p>
      <table width="100%" cellPadding={8} style={{ borderCollapse: "collapse" }}>
        <thead>
          <tr><th align="left">Item</th><th align="right">Qty</th><th align="right">Price</th></tr>
        </thead>
        <tbody>
          {items.map((it, i) => (
            <tr key={i}>
              <td>{it.title}</td>
              <td align="right">{it.qty}</td>
              <td align="right">${it.price.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr><td colSpan={2} align="right">Subtotal</td><td align="right">${subtotal.toFixed(2)}</td></tr>
          <tr><td colSpan={2} align="right">Shipping</td><td align="right">${shipping.toFixed(2)}</td></tr>
          <tr><td colSpan={2} align="right">Tax</td><td align="right">${tax.toFixed(2)}</td></tr>
          <tr><td colSpan={2} align="right"><strong>Total</strong></td><td align="right"><strong>${total.toFixed(2)}</strong></td></tr>
        </tfoot>
      </table>
      <p style={{ marginTop: 16 }}>We&apos;ll email tracking as soon as your package ships.</p>
      <p>— Nature&apos;s Way Soil</p>
    </div>
  );
}
