import Head from "next/head";
import Link from "next/link";

export default function Success() {
  return (
    <main className="min-h-screen bg-white">
      <Head>
        <title>Order Confirmed — Nature&apos;s Way Soil</title>
        <meta name="robots" content="noindex" />
      </Head>
      <div className="mx-auto max-w-xl px-6 py-20 text-center">
        <div className="mx-auto mb-6 h-16 w-16 rounded-full border-2 border-green-600 flex items-center justify-center">
          <span className="text-3xl">✅</span>
        </div>
        <h1 className="text-2xl font-semibold mb-2">Thank you for your order!</h1>
        <p className="text-gray-600 mb-6">
          Your payment was successful. A receipt has been sent to your email.
          You&apos;ll receive shipping updates as soon as your order is on the way.
        </p>
        <div className="space-x-3">
          <Link href="/shop" className="inline-block rounded-md border px-4 py-2">
            Continue Shopping
          </Link>
          <Link href="/" className="inline-block rounded-md bg-green-600 text-white px-4 py-2">
            Back to Home
          </Link>
        </div>
      </div>
    </main>
  );
}
