import HeroVideo from '../components/HeroVideo';

export default function Home() {
  return (
    <>
      <HeroVideo />
    </>
  );
}
