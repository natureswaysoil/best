import { Resend } from "resend";

export const resend = new Resend(process.env.RESEND_API_KEY);

export const RESEND_FROM =
  process.env.RESEND_FROM || "Nature's Way Soil <support@natureswaysoil.com>";

export const SUPPORT_TO = (process.env.SUPPORT_TO ||
  "support@natureswaysoil.com,sales@natureswaysoil.com,james@natureswaysoil.com").split(",");

export const SALES_TO = (process.env.SALES_TO || "sales@natureswaysoil.com").split(",");
export const JAMES_TO = (process.env.JAMES_TO || "james@natureswaysoil.com").split(",");
